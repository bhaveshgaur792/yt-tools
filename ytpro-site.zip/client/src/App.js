import React, { useEffect, useState } from "react";

export default function App() {
  const [videoInfo, setVideoInfo] = useState(null);
  const [channelInfo, setChannelInfo] = useState(null);

  useEffect(() => {
    fetch("/api/video-info")
      .then((res) => res.json())
      .then((data) => setVideoInfo(data));
    fetch("/api/channel-info")
      .then((res) => res.json())
      .then((data) => setChannelInfo(data));
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h1>YouTube Tool</h1>
      {videoInfo && (
        <div style={{ background: "white", padding: "20px", borderRadius: "12px", marginBottom: "20px" }}>
          <h2>Video Info</h2>
          <p><strong>Title:</strong> {videoInfo.title}</p>
          <p><strong>Published Date:</strong> {videoInfo.publishedDate}</p>
          <p><strong>Views:</strong> {videoInfo.views}</p>
          <p><strong>Likes:</strong> {videoInfo.likes}</p>
          <p><strong>Duration:</strong> {videoInfo.duration}</p>
          <p><strong>Language:</strong> {videoInfo.language}</p>
        </div>
      )}
      {channelInfo && (
        <div style={{ background: "white", padding: "20px", borderRadius: "12px" }}>
          <h2>Channel Info</h2>
          <p><strong>Channel Name:</strong> {channelInfo.channelName}</p>
          <p><strong>Subscribers:</strong> {channelInfo.subscribers}</p>
          <p><strong>Monetized:</strong> {channelInfo.monetized ? "Yes" : "No"}</p>
          <p><strong>Creation Date:</strong> {channelInfo.creationDate}</p>
          <p><strong>Country:</strong> {channelInfo.country}</p>
        </div>
      )}
    </div>
  );
}